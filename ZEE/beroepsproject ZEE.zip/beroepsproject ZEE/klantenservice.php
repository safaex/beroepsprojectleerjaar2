<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   <link rel="stylesheet" href="style.2.css">
</head>
<body>
    <div class="banner">
        <div class="navbar">
            <img src="logo1.png" class="logo">

            <ul>
                <li><a href="homepage.php">HOME</a></li>
                <li><a href="overons.php">OVER ONS</a></li>
                <li><a href="klantenservice.php">KLANTENSERVICE</a></li>
                <li><a href="inloggen.php">INLOGGEN</a></li>
              </ul>
    </div>

<h1>Welkom bij onze Klantenservice</h1>
    </header>

    <section id="contact">
        <h2>Contacteer Ons</h2>
        <p>Heb je vragen of opmerkingen? Neem gerust contact met ons op.</p>
        <p>E-mail: <a href="mailto:klantenservice@example.com">klantenservice@example.com</a></p>
        <p>Telefoon: +31 123 456 789</p>
    </section>

    <section id="faq">
        <h2>Veelgestelde vragen</h2>
        <p>Bekijk hier onze veelgestelde vragen en antwoorden.</p>
        <p> hoeveel kost het om een scherm te reparenen? </p>
        <p> hoelang is de garantie op mijn toestel? </p>
        <p> wat zijn de retourkosten? </p>
        <p> 

    
    </section>

    <section id="support">
        <h2>Ondersteuning</h2>
        <p>Heb je technische problemen? Ons supportteam staat klaar om te helpen.</p>
        <p>Supportformulier: <a href="support-form.html">Klik hier</a></p>
    </section>

    <footer>
        <p>&copy; 2023 Bedrijfsnaam. Alle rechten voorbehouden.</p>
    </footer>
</body>
</html>

</body>
</html>