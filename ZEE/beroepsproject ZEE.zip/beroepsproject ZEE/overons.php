<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.2.css">
</head>
<body>
    <div class="banner">
        <div class="navbar">
            <img src="logo1.png" class="logo">

        <ul>
            <li><a href="homepage.php">HOME</a></li>
            <li><a href="overons.php">OVER ONS</a></li>
            <li><a href="klantenservice.php">KLANTENSERVICE</a></li>
            <li><a href="inloggen.php">INLOGGEN</a></li>
        </ul>
    </div>


    <div class="content">
        <h1>PHONIX</h1>
        <p>welkom op PHONIX waar je telefoons kan kopen, reparenen, verkopen en nog veel meer.<br> Wij hebben Van alles tot aan de nieuwste 
          producten naar de 2e handste producten. Ook kan je hoesjes, beschermschermen en nog veel halen in onze winkel.<br> Wij doen ook aan telefoon ruil,
          daarmee bedoel ik dat je je oude telefoon kan inruilen en een bedrag kan terug krijg vanaf $100.<br> Ook kan een abonumenten bij ons aansluiten bij verschillende
          providers, Zoals kpn, Odido, T-mobile of Vodavone.<br> Ben je geinteresseerd in 1 van onze telefoons neem dan een bezoekje in ons winkel. Of neem een
          kijkje bij de telefoons.
        </p>

        
        <div>
        <button onclick="window.location.href = 'samsung.html'">BEKIJK TELEFOONS</button>
        </div>

    </div>
    

</body>
</html>